package com.billing.dao;

import com.billing.bean.Bean;
import com.billing.exception.BilException;

public interface IBilDao {

	Bean getDetailsById(int code) throws BilException;

	boolean insert(Bean bill, int quantity, int line_total) throws BilException;
}
