package com.billing.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.billing.bean.Bean;
import com.billing.exception.BilException;
import com.billing.util.BilUtil;

public class BilDao implements IBilDao {
	Connection conn=null;
	@Override
	public Bean getDetailsById(int code) throws BilException {
		// TODO Auto-generated method stub
			conn=BilUtil.getDbConnection();
			Bean rb1=new Bean();
			try {
				PreparedStatement pst = conn.prepareStatement(IQueryMapper.BILLING_INSERT_QRY);
				pst.setInt(1,code);
				ResultSet rs = pst.executeQuery();
				
				
			while(rs.next())
			{
		rb1.setpCode(rs.getInt(1));
		rb1.setpName(rs.getString(2));
		rb1.setpCat(rs.getString(3));
		rb1.setpDesc(rs.getString(4));
		rb1.setpPrice(rs.getInt(5));
			}
			}catch(SQLException e) {
				throw new BilException("couldn't Retrivedate from db: "+e.getMessage());}
			return rb1;
	}
	@Override
	public boolean insert(Bean bill, int quantity, int line_total) throws BilException {
		// TODO Auto-generated method stub
		conn=BilUtil.getDbConnection();
		int res=0;
		try {
			PreparedStatement pst1 = conn.prepareStatement(IQueryMapper.BILLING_INSERT_QRY2);
			pst1.setInt(1,bill.getpCode());
		pst1.setInt(2, quantity);
		pst1.setInt(3, line_total);
		res=pst1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BilException("data not inserted"+e.getMessage());
		}
		if(res==1) {
			return true;
		}
		else {
		return false;
		}
	}
}
