package com.billing.dao;

public class IQueryMapper {
	public static final String BILLING_INSERT_QRY="SELECT * FROM product WHERE product_code=?";
	public static final String BILLING_INSERT_QRY2="insert into SALES values(seq_1.nextval,?,?,SYSDATE,?)";
}
