package com.billing.service;

import com.billing.bean.Bean;
import com.billing.exception.BilException;

public interface IBillService {
	Bean getDetailsById(int code) throws BilException;
	public boolean validQuantity(int quantity);
	boolean insert(Bean bill, int quantity, int line_total) throws BilException;
}
