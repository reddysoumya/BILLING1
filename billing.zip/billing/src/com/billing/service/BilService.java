package com.billing.service;

import com.billing.bean.Bean;
import com.billing.dao.BilDao;
import com.billing.dao.IBilDao;
import com.billing.exception.BilException;

public class BilService implements IBillService{
	IBilDao bdao=null;
	
	public boolean validQuantity(int quantity) {
		if(quantity>1||quantity==1)
		{
			return true;
		}
		else {
			System.out.println("you are requested to enter atleast one quantity");
			return false;
		}
	}

	@Override
	public Bean getDetailsById(int code) throws BilException {
		// TODO Auto-generated method stub
		bdao=new BilDao();
		return bdao.getDetailsById(code);
	}

	@Override
	public boolean insert(Bean bill, int quantity, int line_total) throws BilException {
		// TODO Auto-generated method stub
		IBilDao bdao1=new BilDao() ;
		return bdao1.insert(bill,quantity,line_total);
	}

	
}
