package com.billing.bean;

public class Bean {
	
private int pCode;
private String pName;
private String pCat;
private String pDesc;
private int pPrice;
private int pQuantity;
private int line_total;


public int getpQuantity() {
	return pQuantity;
}
public void setpQuantity(int pQuantity) {
	this.pQuantity = pQuantity;
}
public int getpCode() {
	return pCode;
}
public void setpCode(int pCode) {
	this.pCode = pCode;
}
public String getpName() {
	return pName;
}
public void setpName(String pName) {
	this.pName = pName;
}
public String getpCat() {
	return pCat;
}
public void setpCat(String pCat) {
	this.pCat = pCat;
}
public String getpDesc() {
	return pDesc;
}
public void setpDesc(String pDesc) {
	this.pDesc = pDesc;
}
public int getpPrice() {
	return pPrice;
}
public void setpPrice(int pPrice) {
	this.pPrice = pPrice;
}
public Bean(int pQuantity, int pCode) {
	super();
	this.pQuantity = pQuantity;
	this.pCode = pCode;
}



public Bean() {
	// TODO Auto-generated constructor stub
}
public Bean(int pCode, String pName, String pCat, String pDesc, int pPrice) {
	super();
	this.pCode = pCode;
	this.pName = pName;
	this.pCat = pCat;
	this.pDesc = pDesc;
	this.pPrice = pPrice;
}
public Bean(int code) {
	// TODO Auto-generated constructor stub
}
public Bean(String getpPrice) {
	// TODO Auto-generated constructor stub
}
public Bean(int quantity, String getpPrice) {
	// TODO Auto-generated constructor stub
}
public Bean(int int1, String string, String string2, String string3, String string4) {
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Bean [pCode=" + pCode + ", pName=" + pName + ", pCat=" + pCat + ", pDesc=" + pDesc + ", pPrice=" + pPrice
			+ "]";
}
public int getLine_total() {
	return line_total;
}
public void setLine_total(int line_total) {
	this.line_total = line_total;
}


}
