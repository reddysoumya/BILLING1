package com.billing.bean;

public class Bean1 {
private int sid;
private int pcode;
private int quantity;
private String date;
private int total;
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public int getPcode() {
	return pcode;
}
public void setPcode(int pcode) {
	this.pcode = pcode;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public int getTotal() {
	return total;
}
public void setTotal(int total) {
	this.total = total;
}
public Bean1(int total) {
	super();
	this.total = total;
}
public Bean1() {
	// TODO Auto-generated constructor stub
}
public Bean1(int quantity2, int getpPrice) {
	// TODO Auto-generated constructor stub
}

}
