package com.billing.exception;

public class BilException extends Exception{
public BilException() {
		
	}
	public BilException(String msg) {
		super(msg);
	}

}
