package com.billing.client;
import java.util.Scanner;

import com.billing.bean.Bean;
import com.billing.exception.BilException;
import com.billing.service.BilService;
import com.billing.service.IBillService;
public class Client {
	static IBillService bilser=null;
	static int p=0;
public static void main(String[] args) throws BilException {
	Scanner sc=new Scanner(System.in);
	bilser=new BilService();
	int quantity;
	boolean res1;
	System.out.println("$$$$---BILLING SYSTEM---$$$$");
	System.out.println("-----------------------------");
	System.out.println("Please enter the product code");
	int code=sc.nextInt();
	do {
	System.out.println("Enter quantity");
	quantity=sc.nextInt();
	res1=bilser.validQuantity(quantity);
	}while(res1==false);
Bean bill=getDetailsById(code);
System.out.println(bill);
int line_total=quantity*bill.getpPrice();
boolean b=insert(bill,quantity,line_total);
if(b==true) {
	System.out.println("sales details inserted");
	System.out.println("Product Name: " + bill.getpName());
	System.out.println("Product Code: " + bill.getpCode());
	System.out.println("Product Description: " + bill.getpDesc());
	System.out.println("Product Price: " + bill.getpPrice());
	System.out.println("Quantity: " + quantity);
	System.out.println("Line Total(Rs): " +line_total);
}
else {
	System.out.println("Details not Inserted");
}
}

private static boolean insert(Bean bill, int quantity, int line_total) throws BilException {
	// TODO Auto-generated method stub
	IBillService bilser1=new BilService();
	return bilser1.insert(bill,quantity,line_total);
}
private static Bean getDetailsById(int code) throws BilException {
	// TODO Auto-generated method stub
	bilser=new BilService();
		return bilser.getDetailsById(code);
}
}


